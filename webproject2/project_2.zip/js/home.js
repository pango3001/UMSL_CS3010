$( function() {
    $( "#datepicker" ).datepicker();
} );